from collections.abc import Callable
from typing import List, Set, Tuple, Optional

import numpy as np
from game import *
from game.enums import Direction, MoveType


class PlayerAgent:
    """
    Chad v6 – Fast explorer + smart turds + Bayesian traps.

    Changes vs v5:
    - Stronger exploration reward, plus bonus for moving to frontier tiles
      (dest with many unvisited neighbors).
    - Slightly reduced trap paranoia so we cross the board faster.
    - Turds only strongly rewarded when:
        * they are near the enemy, AND
        * on the enemy's egg color / useful route.
      Turds far from the enemy get a small penalty.
    """

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------
    def __init__(self, board: "board.Board", time_left: Callable):
        self.board_size: int = board.game_map.MAP_SIZE

        # Spawn / color info
        self.spawn: Tuple[int, int] = board.chicken_player.get_location()
        self.my_parity: int = (self.spawn[0] + self.spawn[1]) % 2
        self.enemy_parity: int = 1 - self.my_parity

        # Path memory
        self.prev_location: Optional[Tuple[int, int]] = None
        self.expected_next_location: Optional[Tuple[int, int]] = None
        self.visited: Set[Tuple[int, int]] = {self.spawn}
        self.recent_positions: List[Tuple[int, int]] = []

        # Bayesian trapdoor beliefs (white: even, black: odd)
        self.belief_white = np.zeros((self.board_size, self.board_size), dtype=float)
        self.belief_black = np.zeros((self.board_size, self.board_size), dtype=float)
        self._init_priors()

        # --- Tunable strategy parameters -------------------------------
        # Egg & exploration
        self.egg_reward: float = 8.0
        self.egg_square_bonus: float = 3.0
        # explore more aggressively
        self.explore_bonus: float = 2.5
        self.frontier_bonus_weight: float = 0.7  # bonus per unvisited neighbor

        # Positioning
        self.center_weight: float = 0.10  # slightly weaker center pull so exploration dominates
        self.backtrack_penalty: float = 2.0
        self.loop_penalty: float = 2.0

        # Trap avoidance (overall a bit less paranoid than v5)
        self.base_trap_penalty: float = 50.0
        self.base_near_trap_penalty: float = 6.0

        # Target steering
        self.target_weight: float = 0.5

        # Turds
        self.turd_block_weight: float = 4.0
        self.enemy_parity_block_bonus: float = 3.0
        self.useless_turd_penalty: float = 2.0
        self.early_turd_cutoff_turn: int = 24  # before this, avoid turds if other actions exist

    # ------------------------------------------------------------------
    # Belief helpers
    # ------------------------------------------------------------------
    def _init_priors(self) -> None:
        """
        Initialize priors: traps more likely in inner rings.
        Ring index = min(x, y, n-1-x, n-1-y).
        Ring 0/1 weight=0, ring 2 weight=1, ring 3 weight=2 (for 8x8).
        """
        n = self.board_size

        total_w = 0.0
        total_b = 0.0
        for x in range(n):
            for y in range(n):
                ring = min(x, y, n - 1 - x, n - 1 - y)
                weight = max(0, ring - 1)  # 0,0,1,2 for rings 0..3

                if weight <= 0:
                    continue

                if (x + y) % 2 == 0:
                    self.belief_white[x, y] = weight
                    total_w += weight
                else:
                    self.belief_black[x, y] = weight
                    total_b += weight

        if total_w > 0:
            self.belief_white /= total_w
        else:
            for x in range(n):
                for y in range(n):
                    if (x + y) % 2 == 0:
                        self.belief_white[x, y] = 1.0
            self.belief_white /= self.belief_white.sum()

        if total_b > 0:
            self.belief_black /= total_b
        else:
            for x in range(n):
                for y in range(n):
                    if (x + y) % 2 == 1:
                        self.belief_black[x, y] = 1.0
            self.belief_black /= self.belief_black.sum()

    @staticmethod
    def _sensor_region(trap_loc: Tuple[int, int], cur_loc: Tuple[int, int]) -> str:
        tx, ty = trap_loc
        cx, cy = cur_loc
        dx = abs(tx - cx)
        dy = abs(ty - cy)

        if dx == 0 and dy == 0:
            return "far"  # standing on trap teleports; treat as far for sensing

        if max(dx, dy) == 1:
            if dx == 1 and dy == 1:
                return "diag"
            else:
                return "edge"

        if max(dx, dy) == 2:
            return "outer"

        return "far"

    @staticmethod
    def _likelihood(region: str, heard: bool, felt: bool) -> float:
        if region == "edge":
            p_h, p_f = 0.50, 0.30
        elif region == "diag":
            p_h, p_f = 0.25, 0.15
        elif region == "outer":
            p_h, p_f = 0.10, 0.00
        else:  # far
            p_h, p_f = 0.0, 0.0

        prob = 1.0
        prob *= p_h if heard else (1.0 - p_h)
        prob *= p_f if felt else (1.0 - p_f)
        return prob

    def _normalize_belief(self, belief: np.ndarray, parity: int) -> None:
        s = float(belief.sum())
        if s > 0.0:
            belief /= s
        else:
            n = self.board_size
            for x in range(n):
                for y in range(n):
                    belief[x, y] = 1.0 if (x + y) % 2 == parity else 0.0
            belief /= belief.sum()

    def _update_beliefs_from_sensors(
        self, current_loc: Tuple[int, int], sensor_data: List[Tuple[bool, bool]]
    ) -> None:
        (heard_w, felt_w), (heard_b, felt_b) = sensor_data

        # White trap
        for x in range(self.board_size):
            for y in range(self.board_size):
                if (x + y) % 2 != 0:
                    continue
                region = self._sensor_region((x, y), current_loc)
                like = self._likelihood(region, heard_w, felt_w)
                self.belief_white[x, y] *= like
        self._normalize_belief(self.belief_white, parity=0)

        # Black trap
        for x in range(self.board_size):
            for y in range(self.board_size):
                if (x + y) % 2 != 1:
                    continue
                region = self._sensor_region((x, y), current_loc)
                like = self._likelihood(region, heard_b, felt_b)
                self.belief_black[x, y] *= like
        self._normalize_belief(self.belief_black, parity=1)

    def _record_teleport_if_any(self, board: "board.Board") -> None:
        current_loc = board.chicken_player.get_location()

        if (
            self.expected_next_location is not None
            and current_loc == self.spawn
            and self.prev_location is not None
            and self.prev_location != self.spawn
        ):
            trap_loc = self.expected_next_location
            x, y = trap_loc
            parity = (x + y) % 2

            if parity == 0:
                self.belief_white[:, :] = 0.0
                self.belief_white[x, y] = 1.0
                self._normalize_belief(self.belief_white, parity=0)
            else:
                self.belief_black[:, :] = 0.0
                self.belief_black[x, y] = 1.0
                self._normalize_belief(self.belief_black, parity=1)

        self.expected_next_location = None

    # ------------------------------------------------------------------
    # Movement helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _next_location(
        loc: Tuple[int, int], direction: Direction
    ) -> Tuple[int, int]:
        x, y = loc
        if direction == Direction.UP:
            return (x, y - 1)
        if direction == Direction.DOWN:
            return (x, y + 1)
        if direction == Direction.LEFT:
            return (x - 1, y)
        if direction == Direction.RIGHT:
            return (x + 1, y)
        return loc

    def _trap_probability(self, loc: Tuple[int, int]) -> float:
        x, y = loc
        if not (0 <= x < self.board_size and 0 <= y < self.board_size):
            return 0.0
        return float(self.belief_white[x, y] + self.belief_black[x, y])

    def _neighbor_trap_probability(self, loc: Tuple[int, int]) -> float:
        x, y = loc
        best = 0.0
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                best = max(best, self._trap_probability((nx, ny)))
        return best

    @staticmethod
    def _manhattan(a: Tuple[int, int], b: Tuple[int, int]) -> int:
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def _frontier_unvisited_neighbors(self, loc: Tuple[int, int]) -> int:
        """Count how many orthogonal neighbors of loc are unvisited."""
        x, y = loc
        count = 0
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                if (nx, ny) not in self.visited:
                    count += 1
        return count

    def _choose_egg_target(
        self, board: "board.Board", current_loc: Tuple[int, int]
    ) -> Optional[Tuple[int, int]]:
        """
        Pick a "nice" target square: our parity, not yet egged, and not super
        likely to be a trap.
        """
        candidates: List[Tuple[int, int]] = []
        for x in range(self.board_size):
            for y in range(self.board_size):
                pos = (x, y)
                if (x + y) % 2 != self.my_parity:
                    continue
                if pos in board.eggs_player:
                    continue
                # allow mild trap probability so we can cross center
                if self._trap_probability(pos) > 0.55:
                    continue
                candidates.append(pos)

        if not candidates:
            return None

        return min(candidates, key=lambda p: self._manhattan(current_loc, p))

    # ------------------------------------------------------------------
    # Scoring (for non-EGG moves)
    # ------------------------------------------------------------------
    def _score_move_non_egg(
        self,
        board: "board.Board",
        move: Tuple[Direction, MoveType],
        target: Optional[Tuple[int, int]],
        risk_factor: float,
    ) -> float:
        direction, move_type = move
        current_loc = board.chicken_player.get_location()
        dest = self._next_location(current_loc, direction)
        turn = board.turn_count

        score = 0.0

        # Scale trap penalties
        turn_factor = max(0.4, 1.0 - turn / 60.0)
        trap_penalty = self.base_trap_penalty * turn_factor * risk_factor
        near_trap_penalty = self.base_near_trap_penalty * turn_factor * risk_factor

        # 1. Trap avoidance
        p_trap = self._trap_probability(dest)
        score -= trap_penalty * p_trap

        near_prob = self._neighbor_trap_probability(dest)
        score -= near_trap_penalty * near_prob

        # 2. Target attraction (toward potential egg squares)
        if target is not None:
            dist_now = self._manhattan(current_loc, target)
            dist_dest = self._manhattan(dest, target)
            score += self.target_weight * (dist_now - dist_dest)

        # 3. Turd-specific logic
        if move_type == MoveType.TURD:
            turds_left = board.chicken_player.get_turds_left()
            cur = current_loc
            enemy_loc = board.chicken_enemy.get_location()

            cx = cy = (self.board_size - 1) / 2.0
            dist_center = abs(cur[0] - cx) + abs(cur[1] - cy)
            dist_enemy = self._manhattan(cur, enemy_loc)

            # Only really like turds if they're semi-close to enemy
            if 2 <= dist_enemy <= 5:
                block_value = 0.0

                # Extra if this tile is on enemy egg color
                if (cur[0] + cur[1]) % 2 == self.enemy_parity:
                    block_value += self.enemy_parity_block_bonus

                # Mild centrality helps when blocking routes
                block_value += max(0.0, 4.0 - dist_center) * 0.5

                # More weight late game or when low turds left
                if turn >= self.early_turd_cutoff_turn or turds_left <= 2:
                    score += self.turd_block_weight * block_value
            else:
                # Turd far from enemy = probably useless
                score -= self.useless_turd_penalty

            if cur == self.spawn:
                score -= 4.0

        # 4. Exploration & frontier
        if dest not in self.visited:
            score += self.explore_bonus
        # Bonus for stepping onto a "frontier" tile with many unvisited neighbors
        frontier_neighbors = self._frontier_unvisited_neighbors(dest)
        score += self.frontier_bonus_weight * frontier_neighbors

        # 5. Central control (small pull)
        cx = cy = (self.board_size - 1) / 2.0
        dist_center_dest = abs(dest[0] - cx) + abs(dest[1] - cy)
        score -= self.center_weight * dist_center_dest

        # 6. Loop avoidance
        if self.prev_location is not None and dest == self.prev_location:
            score -= self.backtrack_penalty
        elif dest in self.recent_positions:
            score -= self.loop_penalty

        return score

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------
    def play(
        self,
        board: "board.Board",
        sensor_data: List[Tuple[bool, bool]],
        time_left: Callable,
    ) -> Tuple[Direction, MoveType]:
        # Check if we just triggered a trapdoor last turn
        self._record_teleport_if_any(board)

        # Bayesian update from sensors
        current_loc = board.chicken_player.get_location()
        self._update_beliefs_from_sensors(current_loc, sensor_data)

        # Egg margin to adapt risk
        own_eggs = len(board.eggs_player)
        enemy_eggs = len(board.eggs_enemy)
        margin = own_eggs - enemy_eggs

        if margin < 0:
            # Behind: more aggressive
            risk_factor = 0.7
            egg_trap_threshold = 0.9
        elif margin > 1:
            # Comfortably ahead
            risk_factor = 1.1
            egg_trap_threshold = 0.6
        else:
            # Close
            risk_factor = 1.0
            egg_trap_threshold = 0.75

        moves = board.get_valid_moves()
        if not moves:
            return (Direction.UP, MoveType.PLAIN)

        # Partition moves by type
        egg_moves = [m for m in moves if m[1] == MoveType.EGG]
        turd_moves = [m for m in moves if m[1] == MoveType.TURD]
        plain_moves = [m for m in moves if m[1] == MoveType.PLAIN]

        # --------------------------------------------------------------
        # 1. EGGS FIRST: If any safe-ish egg move exists, take the best one.
        # --------------------------------------------------------------
        safe_egg_moves: List[Tuple[Direction, MoveType]] = []
        for m in egg_moves:
            direction, _ = m
            dest = self._next_location(current_loc, direction)
            if self._trap_probability(dest) < egg_trap_threshold:
                safe_egg_moves.append(m)

        if safe_egg_moves:
            best_egg = None
            best_score = float("-inf")

            for m in safe_egg_moves:
                direction, _ = m
                dest = self._next_location(current_loc, direction)
                score = 0.0

                # Egg reward
                score += self.egg_reward

                # Exploration & frontier
                if dest not in self.visited:
                    score += self.explore_bonus
                frontier_neighbors = self._frontier_unvisited_neighbors(dest)
                score += self.frontier_bonus_weight * frontier_neighbors

                # Centrality
                cx = cy = (self.board_size - 1) / 2.0
                dist_center_dest = abs(dest[0] - cx) + abs(dest[1] - cy)
                score -= self.center_weight * dist_center_dest

                # Light trap penalty
                score -= 10.0 * self._trap_probability(dest) * risk_factor

                # Avoid trivial backtracking
                if self.prev_location is not None and dest == self.prev_location:
                    score -= 1.5

                if score > best_score:
                    best_score = score
                    best_egg = m

            if best_egg is not None:
                direction, move_type = best_egg
                self.prev_location = current_loc
                self.expected_next_location = self._next_location(current_loc, direction)
                self.visited.add(current_loc)
                self.recent_positions.append(current_loc)
                if len(self.recent_positions) > 6:
                    self.recent_positions.pop(0)
                return best_egg

        # --------------------------------------------------------------
        # 2. NO EGGS AVAILABLE: score PLAIN/TURD moves.
        #    Turds are suppressed early game if any non-turd move exists.
        # --------------------------------------------------------------
        turn = board.turn_count
        non_turd_moves = [m for m in moves if m[1] != MoveType.TURD]

        if turn < self.early_turd_cutoff_turn and non_turd_moves:
            candidate_moves = non_turd_moves
        else:
            candidate_moves = moves

        # Target for guidance
        target = self._choose_egg_target(board, current_loc)

        best_move = None
        best_score = float("-inf")

        for m in candidate_moves:
            score = self._score_move_non_egg(board, m, target, risk_factor)
            if score > best_score:
                best_score = score
                best_move = m

        if best_move is None:
            best_move = moves[0]

        direction, move_type = best_move

        # Update memories
        self.prev_location = current_loc
        self.expected_next_location = self._next_location(current_loc, direction)
        self.visited.add(current_loc)
        self.recent_positions.append(current_loc)
        if len(self.recent_positions) > 6:
            self.recent_positions.pop(0)

        return best_move
