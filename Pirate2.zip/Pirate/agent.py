from collections.abc import Callable
from typing import List, Tuple, Optional, Dict, Set
import numpy as np

from game import *
from game.enums import Direction, MoveType


# ================================================================
# PlayerAgent – PIRATE v3 (Sensor-Guided Explorer)
# ================================================================
class PlayerAgent:
    """
    PIRATE v3 - Smart exploration based on sensor confidence:
    - Build confidence map from sensor readings
    - Explore aggressively in CONFIRMED safe zones
    - Never revisit tiles (maximum coverage)
    - Avoid uncertain areas, not just edges
    - Use silence as strong safety signal
    """

    def __init__(self, board: board.Board, time_left: Callable):
        self.board_size = board.game_map.MAP_SIZE

        # Parity detection
        self.my_egg_parity: Optional[int] = None

        # Trapdoor probability beliefs
        self.belief_white = np.zeros((self.board_size, self.board_size))
        self.belief_black = np.zeros((self.board_size, self.board_size))
        self._init_trapdoor_beliefs()

        # CONFIDENCE MAP - how sure are we each tile is SAFE?
        # Higher = more confident it's safe
        self.safety_confidence = np.zeros((self.board_size, self.board_size))

        # Confirmed traps
        self.confirmed_trapdoors: Set[Tuple[int, int]] = set()

        # Movement tracking - CRITICAL for no-revisit
        self.visited: Set[Tuple[int, int]] = set()
        self.visit_order: List[Tuple[int, int]] = []

        # Direction for momentum
        self.last_direction: Optional[Direction] = None
        self.prev_loc: Optional[Tuple[int, int]] = None

        # Egg tracking
        self.egg_squares: Set[Tuple[int, int]] = set()

        self.turn_index = 0

    def _init_trapdoor_beliefs(self):
        """Initialize uniform prior - trapdoors are within 2 of center"""
        center = self.board_size // 2
        for y in range(self.board_size):
            for x in range(self.board_size):
                # Trapdoors only on matching parity squares
                dist_from_center = abs(x - center + 0.5) + abs(y - center + 0.5)
                
                if (x + y) % 2 == 0:
                    # White trap on even squares, more likely near center
                    if dist_from_center <= 3:
                        self.belief_white[y][x] = 2.0
                    else:
                        self.belief_white[y][x] = 0.5
                else:
                    # Black trap on odd squares
                    if dist_from_center <= 3:
                        self.belief_black[y][x] = 2.0
                    else:
                        self.belief_black[y][x] = 0.5
        self._normalize()

    def _normalize(self):
        w_sum = self.belief_white.sum()
        b_sum = self.belief_black.sum()
        if w_sum > 1e-12:
            self.belief_white /= w_sum
        if b_sum > 1e-12:
            self.belief_black /= b_sum

    def _trapdoor_risk(self, x, y) -> float:
        """Combined probability this tile has a trapdoor"""
        if 0 <= x < self.board_size and 0 <= y < self.board_size:
            return float(self.belief_white[y][x] + self.belief_black[y][x])
        return 1.0

    def _apply_dir(self, loc: Tuple[int, int], d: Direction) -> Tuple[int, int]:
        x, y = loc
        if d == Direction.UP:
            return x, y - 1
        elif d == Direction.DOWN:
            return x, y + 1
        elif d == Direction.LEFT:
            return x - 1, y
        elif d == Direction.RIGHT:
            return x + 1, y
        return x, y

    def _opposite_dir(self, d: Direction) -> Direction:
        if d == Direction.UP:
            return Direction.DOWN
        elif d == Direction.DOWN:
            return Direction.UP
        elif d == Direction.LEFT:
            return Direction.RIGHT
        elif d == Direction.RIGHT:
            return Direction.LEFT
        return d

    def _record_trap(self, loc):
        """Record a confirmed trapdoor"""
        self.confirmed_trapdoors.add(loc)
        x, y = loc
        # Zero out belief for this trap
        self.belief_white[y][x] = 0
        self.belief_black[y][x] = 0
        # Set confidence to -infinity (definitely dangerous)
        self.safety_confidence[y][x] = -100
        self._normalize()

    def _bayes_update(self, loc, sensors):
        """Update beliefs based on sensor readings - THE KEY TO SMART PLAY"""
        (hw, fw), (hb, fb) = sensors
        lx, ly = loc

        # Update belief grids
        self._update_belief_grid(self.belief_white, 0, loc, hw, fw)
        self._update_belief_grid(self.belief_black, 1, loc, hb, fb)
        self._normalize()

        # ===== CRITICAL: UPDATE CONFIDENCE BASED ON SENSORS =====
        
        # If we heard/felt something, nearby tiles are MORE dangerous
        if hw or fw or hb or fb:
            # Danger nearby! Reduce confidence in adjacent tiles
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    nx, ny = lx + dx, ly + dy
                    if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                        dist = abs(dx) + abs(dy)
                        if dist <= 2:
                            # Reduce confidence based on signal strength
                            penalty = -3.0 if (fw or fb) else -1.5  # Felt is stronger signal
                            if dist == 1:
                                self.safety_confidence[ny][nx] += penalty * 2
                            elif dist == 2:
                                self.safety_confidence[ny][nx] += penalty
        else:
            # ===== NO SIGNAL = STRONG SAFETY INDICATOR =====
            # This is the key insight - silence means nearby is SAFE
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    nx, ny = lx + dx, ly + dy
                    if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                        dist = abs(dx) + abs(dy)
                        if dist <= 2:
                            # BOOST confidence - no signal means safe!
                            if dist <= 1:
                                self.safety_confidence[ny][nx] += 4.0  # Very confident
                                # Also reduce trapdoor probability
                                self.belief_white[ny][nx] *= 0.1
                                self.belief_black[ny][nx] *= 0.1
                            else:
                                self.safety_confidence[ny][nx] += 2.0
                                self.belief_white[ny][nx] *= 0.4
                                self.belief_black[ny][nx] *= 0.4
            self._normalize()

        # Mark current location as CONFIRMED SAFE (we're standing on it!)
        self.safety_confidence[ly][lx] = 50.0  # Very high confidence
        self.belief_white[ly][lx] = 0
        self.belief_black[ly][lx] = 0

    def _update_belief_grid(self, grid, parity, loc, heard, felt):
        """Bayesian update for trapdoor location"""
        like = np.ones_like(grid)
        for y in range(self.board_size):
            for x in range(self.board_size):
                if (x + y) % 2 != parity:
                    continue
                p_h, p_f = self._signal_prob(loc, (x, y))
                like[y][x] *= (p_h if heard else (1 - p_h))
                like[y][x] *= (p_f if felt else (1 - p_f))
        grid *= like

    def _signal_prob(self, here, trap):
        """Probability of hearing/feeling based on distance"""
        hx, hy = here
        tx, ty = trap
        dx, dy = abs(hx - tx), abs(hy - ty)

        if dx + dy == 1:  # Adjacent
            return 0.50, 0.30
        if dx == 1 and dy == 1:  # Diagonal
            return 0.25, 0.15
        if dx + dy == 2:  # Distance 2
            return 0.10, 0.00
        return 0.00, 0.00

    def _is_safe_to_move(self, x, y) -> bool:
        """Check if we're confident a tile is safe"""
        if (x, y) in self.confirmed_trapdoors:
            return False
        
        risk = self._trapdoor_risk(x, y)
        confidence = self.safety_confidence[y][x] if 0 <= x < self.board_size and 0 <= y < self.board_size else -100
        
        # Safe if: low risk OR high confidence
        return risk < 0.12 or confidence > 5.0

    def _score_move(self, move, board_state, cx, cy) -> float:
        d, mt = move
        nx, ny = self._apply_dir((cx, cy), d)
        dest = (nx, ny)

        # Hard ban on confirmed traps
        if dest in self.confirmed_trapdoors:
            return -1e12

        risk = self._trapdoor_risk(nx, ny)
        confidence = self.safety_confidence[ny][nx] if 0 <= nx < self.board_size and 0 <= ny < self.board_size else -100

        # ===== DANGER CHECK =====
        # Only ban if BOTH high risk AND low confidence
        if risk > 0.15 and confidence < 3.0:
            return -1e9
        
        # Moderate caution for uncertain tiles
        if risk > 0.10 and confidence < 0:
            return -1e6

        util = 0.0

        # ========== EGG IS KING ==========
        if mt == MoveType.EGG:
            util += 1000

            # Corner eggs worth 3 extra points!
            is_corner = (cx in (0, self.board_size - 1)) and (cy in (0, self.board_size - 1))
            if is_corner:
                util += 500

            # Slight risk adjustment
            util -= 150 * risk
            util += 20 * confidence  # Prefer laying eggs in confident areas

        # ========== NEVER REVISIT (CRITICAL) ==========
        if dest in self.visited:
            util -= 800  # MASSIVE penalty for revisiting
        else:
            util += 200  # Big bonus for new tiles

        # ========== EXPLORATION BASED ON CONFIDENCE ==========
        # If we're confident an area is safe, explore it!
        if confidence > 5.0:
            util += 100  # Go to confirmed safe areas
        elif confidence > 0:
            util += 50
        elif confidence < -5.0:
            util -= 200  # Avoid areas we think are dangerous

        # ========== DIRECTION MOMENTUM ==========
        if self.last_direction is not None:
            if d == self.last_direction:
                util += 80  # Keep going same direction
            elif d == self._opposite_dir(self.last_direction):
                util -= 300  # Don't backtrack

        # ========== AVOID GOING BACK TO PREV LOC ==========
        if dest == self.prev_loc:
            util -= 500

        # ========== RISK PENALTY ==========
        util -= 100 * risk
        
        # ========== CONFIDENCE BONUS ==========
        util += 15 * confidence

        # ========== TURD STRATEGY ==========
        if mt == MoveType.TURD:
            ox, oy = board_state.chicken_enemy.get_location()
            dist = abs(cx - ox) + abs(cy - oy)

            # Block opponent's egg squares
            if self.my_egg_parity is not None:
                opp_parity = 1 - self.my_egg_parity
                if (cx + cy) % 2 == opp_parity:
                    util += 100
                    # Blocking opponent corner is huge
                    if (cx in (0, self.board_size - 1)) and (cy in (0, self.board_size - 1)):
                        util += 200

            if 2 <= dist <= 4:
                util += 50
            elif dist <= 1:
                util -= 200

            # Save turds for mid-game
            if self.turn_index < 10:
                util -= 60

        return util + np.random.random() * 0.01

    def _choose_move(self, board_state, sensors, time_left):
        moves = board_state.get_valid_moves()
        if not moves:
            return None

        cx, cy = board_state.chicken_player.get_location()

        # PRIORITY 1: Egg moves (if safe)
        egg_moves = [m for m in moves if m[1] == MoveType.EGG]
        if egg_moves:
            scored_eggs = [(self._score_move(m, board_state, cx, cy), m) for m in egg_moves]
            scored_eggs.sort(key=lambda x: x[0], reverse=True)
            best_egg = scored_eggs[0]
            if best_egg[0] > -1e6:  # Not suicidal
                return best_egg[1]

        # PRIORITY 2: Score all moves
        scored = [(self._score_move(m, board_state, cx, cy), m) for m in moves]
        scored.sort(key=lambda x: x[0], reverse=True)

        # If all moves look bad, pick the least bad
        return scored[0][1]

    def play(self, board_state: board.Board, sensors, time_left: Callable):
        self.turn_index += 1

        # Update confirmed traps
        try:
            for loc in board_state.found_trapdoors:
                if loc not in self.confirmed_trapdoors:
                    self._record_trap(loc)
        except:
            pass

        cx, cy = board_state.chicken_player.get_location()
        
        # ===== BAYESIAN + CONFIDENCE UPDATE =====
        self._bayes_update((cx, cy), sensors)

        # Mark current location as visited
        self.visited.add((cx, cy))
        self.visit_order.append((cx, cy))

        moves = board_state.get_valid_moves()
        if not moves:
            return None

        # Detect parity
        if self.my_egg_parity is None:
            for m in moves:
                if m[1] == MoveType.EGG:
                    self.my_egg_parity = (cx + cy) % 2
                    break

        # Choose move
        chosen = self._choose_move(board_state, sensors, time_left)
        if chosen is None:
            return moves[0]

        # Update tracking
        d, mt = chosen
        nx, ny = self._apply_dir((cx, cy), d)

        self.last_direction = d
        self.prev_loc = (cx, cy)

        if mt == MoveType.EGG:
            self.egg_squares.add((cx, cy))

        return chosen
