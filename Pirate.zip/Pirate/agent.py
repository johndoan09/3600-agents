from collections.abc import Callable
from typing import List, Tuple, Optional, Dict, Set
import numpy as np

from game import *
from game.enums import Direction, MoveType


# ================================================================
# PlayerAgent – PIRATE (Aggressive Edge-Sweeper)
# ================================================================
class PlayerAgent:
    """
    PIRATE - Aggressive Edge-Sweeping Strategy:
    - ALWAYS lay eggs when possible
    - Strong directional momentum (no bouncing back)
    - Systematic edge patrol
    - Higher risk tolerance
    - Minimal looping
    """

    def __init__(self, board: board.Board, time_left: Callable):
        self.board_size = board.game_map.MAP_SIZE

        # Parity detection
        self.my_egg_parity: Optional[int] = None

        # Trapdoor beliefs
        self.belief_white = np.zeros((self.board_size, self.board_size))
        self.belief_black = np.zeros((self.board_size, self.board_size))
        self._init_trapdoor_beliefs()

        # Danger memory
        self.confirmed_trapdoors: Set[Tuple[int, int]] = set()

        # Movement tracking
        self.visited_counts: Dict[Tuple[int, int], int] = {}
        self.recent_positions: List[Tuple[int, int]] = []
        self.max_recent = 8

        # Direction momentum - KEY FOR NO LOOPS
        self.last_direction: Optional[Direction] = None
        self.prev_loc: Optional[Tuple[int, int]] = None

        # Egg tracking
        self.egg_squares: Set[Tuple[int, int]] = set()

        self.turn_index = 0

        # MORE AGGRESSIVE thresholds
        self.HARD_RISK_LIMIT = 0.15  # Only avoid if really dangerous

    def _init_trapdoor_beliefs(self):
        for y in range(self.board_size):
            for x in range(self.board_size):
                if (x + y) % 2 == 0:
                    self.belief_white[y][x] = 1
                else:
                    self.belief_black[y][x] = 1
        self._normalize()

    def _normalize(self):
        w_sum = self.belief_white.sum()
        b_sum = self.belief_black.sum()
        if w_sum > 1e-12:
            self.belief_white /= w_sum
        if b_sum > 1e-12:
            self.belief_black /= b_sum

    def _trapdoor_risk(self, x, y):
        if 0 <= x < self.board_size and 0 <= y < self.board_size:
            return float(self.belief_white[y][x] + self.belief_black[y][x])
        return 1.0

    def _apply_dir(self, loc: Tuple[int, int], d: Direction) -> Tuple[int, int]:
        x, y = loc
        if d == Direction.UP:
            return x, y - 1
        elif d == Direction.DOWN:
            return x, y + 1
        elif d == Direction.LEFT:
            return x - 1, y
        elif d == Direction.RIGHT:
            return x + 1, y
        return x, y

    def _opposite_dir(self, d: Direction) -> Direction:
        """Get the opposite direction"""
        if d == Direction.UP:
            return Direction.DOWN
        elif d == Direction.DOWN:
            return Direction.UP
        elif d == Direction.LEFT:
            return Direction.RIGHT
        elif d == Direction.RIGHT:
            return Direction.LEFT
        return d

    def _clockwise_dir(self, d: Direction) -> Direction:
        """Get next clockwise direction for edge patrol"""
        if d == Direction.UP:
            return Direction.RIGHT
        elif d == Direction.RIGHT:
            return Direction.DOWN
        elif d == Direction.DOWN:
            return Direction.LEFT
        elif d == Direction.LEFT:
            return Direction.UP
        return d

    def _record_trap(self, loc):
        self.confirmed_trapdoors.add(loc)
        x, y = loc
        if (x + y) % 2 == 0:
            self.belief_white[y][x] = 0
        else:
            self.belief_black[y][x] = 0
        self._normalize()

    def _bayes_update(self, loc, sensors):
        (hw, fw), (hb, fb) = sensors

        self._update_belief_grid(self.belief_white, 0, loc, hw, fw)
        self._update_belief_grid(self.belief_black, 1, loc, hb, fb)
        self._normalize()

        # No signal = nearby is safer
        if not (hw or fw or hb or fb):
            lx, ly = loc
            for y in range(self.board_size):
                for x in range(self.board_size):
                    dist = abs(x - lx) + abs(y - ly)
                    if dist <= 2:
                        decay = 0.25 if dist <= 1 else 0.5
                        self.belief_white[y][x] *= decay
                        self.belief_black[y][x] *= decay
            self._normalize()

    def _update_belief_grid(self, grid, parity, loc, heard, felt):
        like = np.ones_like(grid)
        for y in range(self.board_size):
            for x in range(self.board_size):
                if (x + y) % 2 != parity:
                    continue
                p_h, p_f = self._signal_prob(loc, (x, y))
                like[y][x] *= (p_h if heard else (1 - p_h))
                like[y][x] *= (p_f if felt else (1 - p_f))
        grid *= like

    def _signal_prob(self, here, trap):
        hx, hy = here
        tx, ty = trap
        dx, dy = abs(hx - tx), abs(hy - ty)

        if dx + dy == 1:
            return 0.50, 0.30
        if dx == 1 and dy == 1:
            return 0.25, 0.15
        if dx + dy == 2:
            return 0.10, 0.00
        return 0.00, 0.00

    def _is_on_edge(self, x, y) -> bool:
        return x == 0 or x == self.board_size - 1 or y == 0 or y == self.board_size - 1

    def _is_corner(self, x, y) -> bool:
        return (x in (0, self.board_size - 1)) and (y in (0, self.board_size - 1))

    def _get_edge_direction(self, x, y) -> Optional[Direction]:
        """Get the direction to follow along the edge (clockwise)"""
        # Top edge: go right
        if y == 0 and x < self.board_size - 1:
            return Direction.RIGHT
        # Right edge: go down
        if x == self.board_size - 1 and y < self.board_size - 1:
            return Direction.DOWN
        # Bottom edge: go left
        if y == self.board_size - 1 and x > 0:
            return Direction.LEFT
        # Left edge: go up
        if x == 0 and y > 0:
            return Direction.UP
        return None

    def _score_move(self, move, board_state, cx, cy) -> float:
        d, mt = move
        nx, ny = self._apply_dir((cx, cy), d)
        dest = (nx, ny)

        risk = self._trapdoor_risk(nx, ny)

        # Hard ban on confirmed traps
        if dest in self.confirmed_trapdoors:
            return -1e12

        # High risk penalty but not absolute ban
        if risk > self.HARD_RISK_LIMIT:
            return -1e9

        util = 0.0

        # ========== EGG IS KING ==========
        if mt == MoveType.EGG:
            util += 1000  # Always prioritize eggs
            
            # Corner eggs are MASSIVE (worth 3 extra points!)
            if self._is_corner(cx, cy):
                util += 500
            
            # Slight risk adjustment for eggs
            util -= 200 * risk

        # ========== DIRECTION MOMENTUM (CRITICAL FOR NO LOOPS) ==========
        if self.last_direction is not None:
            # HUGE bonus for continuing same direction
            if d == self.last_direction:
                util += 150
            # SEVERE penalty for going backwards
            elif d == self._opposite_dir(self.last_direction):
                util -= 500  # Really punish backtracking
            # Small bonus for turning (edge patrol)
            else:
                util += 20

        # ========== EDGE PATROL ==========
        if self._is_on_edge(nx, ny):
            util += 80
            # Extra bonus for following the edge direction
            edge_dir = self._get_edge_direction(cx, cy)
            if edge_dir is not None and d == edge_dir:
                util += 100

        # Corner positioning (good for eggs on parity)
        if self._is_corner(nx, ny):
            if self.my_egg_parity is not None and (nx + ny) % 2 == self.my_egg_parity:
                util += 60  # Good corner for us

        # ========== ANTI-LOOP ==========
        # Severe penalty for going back to previous location
        if dest == self.prev_loc:
            util -= 400

        # Penalty for recently visited
        recent_count = self.recent_positions.count(dest)
        util -= 100 * recent_count

        # Penalty for frequently visited
        visit_count = self.visited_counts.get(dest, 0)
        util -= 50 * visit_count

        # ========== EXPLORATION ==========
        if dest not in self.visited_counts:
            util += 60

        # ========== TURD STRATEGY ==========
        if mt == MoveType.TURD:
            ox, oy = board_state.chicken_enemy.get_location()
            dist = abs(cx - ox) + abs(cy - oy)
            
            # Block opponent's egg squares
            if self.my_egg_parity is not None:
                opp_parity = 1 - self.my_egg_parity
                if (cx + cy) % 2 == opp_parity:
                    util += 100
                    if self._is_corner(cx, cy):
                        util += 200  # Block opponent corner

            if 2 <= dist <= 4:
                util += 50
            elif dist <= 1:
                util -= 200  # Can't place here anyway
            
            # Save turds for mid-game
            if self.turn_index < 10:
                util -= 80

        # ========== RISK PENALTY ==========
        util -= 80 * risk

        return util + np.random.random() * 0.01

    def _choose_move(self, board_state, sensors, time_left):
        moves = board_state.get_valid_moves()
        if not moves:
            return None

        cx, cy = board_state.chicken_player.get_location()

        # PRIORITY 1: Always take egg moves if available and not suicidal
        egg_moves = [m for m in moves if m[1] == MoveType.EGG]
        if egg_moves:
            scored_eggs = [(self._score_move(m, board_state, cx, cy), m) for m in egg_moves]
            scored_eggs.sort(key=lambda x: x[0], reverse=True)
            best_egg = scored_eggs[0]
            # Take egg if it's not terrible
            if best_egg[0] > -1e8:
                return best_egg[1]

        # PRIORITY 2: Score all moves
        scored = [(self._score_move(m, board_state, cx, cy), m) for m in moves]
        scored.sort(key=lambda x: x[0], reverse=True)

        return scored[0][1]

    def play(self, board_state: board.Board, sensors, time_left: Callable):
        self.turn_index += 1

        # Update confirmed traps
        try:
            for loc in board_state.found_trapdoors:
                if loc not in self.confirmed_trapdoors:
                    self._record_trap(loc)
        except:
            pass

        cx, cy = board_state.chicken_player.get_location()
        self._bayes_update((cx, cy), sensors)

        moves = board_state.get_valid_moves()
        if not moves:
            return None

        # Detect parity
        if self.my_egg_parity is None:
            for m in moves:
                if m[1] == MoveType.EGG:
                    self.my_egg_parity = (cx + cy) % 2
                    break

        # Choose move
        chosen = self._choose_move(board_state, sensors, time_left)
        if chosen is None:
            return moves[0]

        # Update tracking
        d, mt = chosen
        nx, ny = self._apply_dir((cx, cy), d)

        self.last_direction = d  # Track direction for momentum
        self.prev_loc = (cx, cy)

        self.visited_counts[(nx, ny)] = self.visited_counts.get((nx, ny), 0) + 1
        self.recent_positions.append((nx, ny))
        if len(self.recent_positions) > self.max_recent:
            self.recent_positions.pop(0)

        if mt == MoveType.EGG:
            self.egg_squares.add((cx, cy))

        return chosen

